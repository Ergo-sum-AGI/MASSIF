# =====================================================================
# CELL 7: EXECUTE — Run the Analysis
# =====================================================================

print("\n" + "="*70)
print("MASSIF MONITOR — MAIN EXECUTION")
print("="*70)

# Check if we're in the right environment
if EXECUTION_MODE == "CPU_ONLY":
    print("\n⚠️ Running on CPU. This will be SLOW and may use reduced parameters.")
    print("   Consider switching to GPU runtime for full analysis.\n")
    N_RUNS = 6      # Reduced for CPU
    MAX_TOKENS = 15  # Reduced for CPU
else:
    print("\n✓ GPU detected. Running full analysis.\n")
    N_RUNS = 12
    MAX_TOKENS = 25

# Run GPT-2 analysis
print("\n" + "▶"*35)
gpt2_results = run_massif_analysis(
    model_id="gpt2",
    model_name="GPT-2 Small",
    prompt="I " * 6,
    n_runs=N_RUNS,
    max_tokens=MAX_TOKENS
)

# Save results
orchestrator.save("gpt2_analysis", gpt2_results)

# If GPU available, run Qwen as well
if HAS_GPU:
    print("\n" + "▶"*35)
    qwen_results = run_massif_analysis(
        model_id="Qwen/Qwen2-0.5B",
        model_name="Qwen2-0.5B",
        prompt="I " * 6,
        n_runs=N_RUNS,
        max_tokens=MAX_TOKENS
    )
    orchestrator.save("qwen_analysis", qwen_results)
    
    # Compare
    print("\n" + "="*70)
    print("COMPARISON: GPT-2 vs Qwen2")
    print("="*70)
    print(f"{'Metric':<30} {'GPT-2':<15} {'Qwen2':<15}")
    print("-"*60)
    print(f"{'Final I_t':<30} {gpt2_results['hierarchy']['mean_I'][-1]:+.4f}       {qwen_results['hierarchy']['mean_I'][-1]:+.4f}")
    print(f"{'Max tension σ_t':<30} {gpt2_results['failures']['max_tension']:.4f}        {qwen_results['failures']['max_tension']:.4f}")
    print(f"{'Instability score':<30} {gpt2_results['failures']['instability_score']:.2f}         {qwen_results['failures']['instability_score']:.2f}")
    print(f"{'Active failures':<30} {str(gpt2_results['failures']['active']):<15} {str(qwen_results['failures']['active']):<15}")
else:
    print("\n⚠️ Qwen analysis skipped (requires GPU).")
    print("   Run on GPU runtime to compare Qwen vs GPT-2.")

print("\n" + "="*70)
print("✅ MASSIF MONITOR COMPLETE")
print("="*70)
print(f"Checkpoints saved to: {CHECKPOINT_DIR}")
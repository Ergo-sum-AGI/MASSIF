# =====================================================================
# CELL 6: MAIN ANALYSIS RUN (Execute This)
# =====================================================================
# TASK: Run complete MASSIF analysis on specified model
# =====================================================================

def run_massif_analysis(model_id, model_name, prompt="I "*6, n_runs=10, max_tokens=25):
    """
    Complete MASSIF pipeline:
    1. Compute persistence traces
    2. Build hierarchy (I_t, σ_t, Φ_t, Ψ_t, κ_t)
    3. Classify failures
    4. Return all results
    """
    
    print("\n" + "="*70)
    print(f"MASSIF ANALYSIS: {model_name}")
    print("="*70)
    print(f"Prompt: '{prompt}'")
    print(f"Runs: {n_runs}, Max tokens: {max_tokens}")
    
    # Load model
    model, tokenizer, interface = load_model_with_interface(model_id, model_name)
    
    # Compute persistence traces
    print("\n📊 Computing persistence traces...")
    traces, tokens = compute_persistence_ensemble(
        interface, tokenizer, prompt,
        max_tokens=max_tokens, temperature=0.7,
        n_runs=n_runs
    )
    
    # Build hierarchy
    print("📈 Building MASSIF hierarchy...")
    hierarchy = compute_massif_hierarchy(traces, window_k=4, window_m=3)
    
    # Classify failures
    print("🔍 Classifying failure modes...")
    failures = classify_failures(hierarchy)
    
    # Summary
    print("\n" + "-"*50)
    print("RESULTS SUMMARY")
    print("-"*50)
    print(f"  Final mean persistence I_t: {hierarchy['mean_I'][-1]:+.4f}" if hierarchy['mean_I'] else "  No data")
    print(f"  Max tension σ_t:           {failures['max_tension']:.4f}")
    print(f"  Instability score:         {failures['instability_score']:.2f}")
    print(f"  Active failures:           {failures['active'] if failures['active'] else 'None'}")
    print("-"*50)
    
    # Plot
    plot_massif_dashboard(hierarchy, failures, model_name)
    
    # Cleanup
    del model
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    
    return {
        'hierarchy': hierarchy,
        'failures': failures,
        'traces': traces,
        'model_name': model_name
    }


def plot_massif_dashboard(hierarchy, failures, model_name):
    """Create the 5-panel MASSIF dashboard."""
    
    steps = range(len(hierarchy['mean_I']))
    
    fig, axes = plt.subplots(5, 1, figsize=(12, 12))
    fig.suptitle(f"MASSIF Dashboard: {model_name}\nInstability Score: {failures['instability_score']:.2f}", 
                 fontsize=12, fontweight='bold')
    
    # Panel 1: I_t (persistence)
    ax = axes[0]
    ax.plot(steps, hierarchy['mean_I'], 'b-', linewidth=2)
    ax.axhline(0, color='red', linestyle='--', alpha=0.7, label='Flip boundary')
    ax.set_ylabel(r'$I_t$ (persistence)')
    ax.set_title('Level 1: Persistence')
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    
    # Panel 2: σ_t (local tension — TEMPORAL SEQUENCE)
    ax = axes[1]
    ax.fill_between(steps, 0, hierarchy['sigma_t'], alpha=0.3, color='purple')
    ax.plot(steps, hierarchy['sigma_t'], 'purple', linewidth=2)
    ax.axhline(0.35, color='orange', linestyle='--', alpha=0.7, label='Critical tension')
    ax.set_ylabel(r'$\sigma_t$ (tension)')
    ax.set_title('Level 2: Local Tension (rolling std) — NOTE: This is a SEQUENCE, not a scalar')
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    
    # Panel 3: Φ_t (volatility gradient)
    ax = axes[2]
    phi_steps = range(len(hierarchy['phi_t']))
    colors = ['red' if x > 0 else 'blue' if x < 0 else 'gray' for x in hierarchy['phi_t']]
    ax.bar(phi_steps, hierarchy['phi_t'], color=colors, alpha=0.7)
    ax.axhline(0, color='black', alpha=0.5)
    ax.set_ylabel(r'$\Phi_t$ (gradient)')
    ax.set_title('Level 3: Volatility Gradient (dσ/dt)')
    ax.grid(True, alpha=0.3)
    
    # Panel 4: Ψ_t (stress velocity)
    ax = axes[3]
    ax.plot(steps, hierarchy['psi_t'], 'darkred', linewidth=2)
    ax.axhline(0, color='black', alpha=0.5)
    ax.axhline(0.04, color='orange', linestyle='--', alpha=0.7, label='Warning')
    ax.set_ylabel(r'$\Psi_t$ (stress velocity)')
    ax.set_title('Level 4: Predictive Volatility Velocity')
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    
    # Panel 5: κ_t (curvature)
    ax = axes[4]
    ax.plot(steps, hierarchy['kappa_t'], 'green', linewidth=2)
    ax.axhline(0.2, color='red', linestyle='--', alpha=0.7, label='Collapse threshold')
    ax.set_ylabel(r'$\kappa_t$ (curvature)')
    ax.set_xlabel('Generation step')
    ax.set_title('Level 5: Curvature (arccos(I_t))')
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f"massif_dashboard_{model_name.replace(' ', '_').lower()}.png", dpi=150)
    plt.show()


print("✅ Cell 6 complete: Run function defined")
# =====================================================================
# CELL 2: PERSISTENCE COMPUTATION (I_t)
# =====================================================================
# TASK: Compute raw persistence traces from model forward passes
# =====================================================================

import torch

def compute_persistence_trace(model_interface, tokenizer, prompt,
                               max_tokens=25, temperature=0.7, seed=42):
    """
    Compute I_t persistence trace for a single run.
    
    Formula:
        v_t = ĥ_t - ĥ_{t-1}
        I_t = (v_t · v_{t-1}) / (||v_t|| ||v_{t-1}|| + ε)
    """
    if seed is not None:
        torch.manual_seed(seed)
        np.random.seed(seed)
    
    inputs = tokenizer(prompt, return_tensors='pt').to(model_interface.device)
    input_ids = inputs.input_ids
    
    h_prev = None
    v_prev = None
    persistence_trace = []
    token_trace = []
    
    with torch.no_grad():
        for step in range(max_tokens):
            canonical = model_interface.forward(input_ids)
            
            if canonical['last_hidden'] is None:
                break
            
            logits = canonical['logits'][0, -1]
            h_new = canonical['last_hidden'][0, -1]
            
            # Normalize hidden state: ĥ_t = h_t / ||h_t||
            hu = h_new / (torch.norm(h_new) + 1e-6)
            
            if h_prev is not None:
                # v_t = ĥ_t - ĥ_{t-1}
                v_t = hu - h_prev
                
                if v_prev is not None:
                    # I_t = (v_t · v_{t-1}) / (||v_t|| ||v_{t-1}||)
                    dot = torch.dot(v_t, v_prev)
                    norm_product = torch.norm(v_t) * torch.norm(v_prev) + 1e-6
                    persistence = float(dot / norm_product)
                    persistence_trace.append(persistence)
                
                v_prev = v_t.clone()
            
            h_prev = hu.clone()
            
            # Sample next token
            if temperature > 0:
                probs = torch.softmax(logits / temperature, dim=-1)
                next_token = torch.multinomial(probs, 1)
            else:
                next_token = torch.argmax(logits, keepdim=True)
            
            token_trace.append(next_token.item())
            input_ids = torch.cat([input_ids, next_token.unsqueeze(0)], dim=1)
            
            if next_token.item() == tokenizer.eos_token_id:
                break
    
    return persistence_trace, token_trace


def compute_persistence_ensemble(model_interface, tokenizer, prompt,
                                  max_tokens=25, temperature=0.7, n_runs=10):
    """Collect persistence traces across multiple runs."""
    all_traces = []
    all_tokens = []
    
    for run in range(n_runs):
        trace, tokens = compute_persistence_trace(
            model_interface, tokenizer, prompt,
            max_tokens=max_tokens, temperature=temperature,
            seed=42 + run
        )
        all_traces.append(trace)
        all_tokens.append(tokens)
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    
    return all_traces, all_tokens

print("✅ Cell 2 complete: Persistence computation defined")
# =====================================================================
# CELL 3: FAILURE MODE CLASSIFICATION
# =====================================================================
# TASK: Classify different failure signatures using the hierarchy
#
# Failure Mode              | Signature
# --------------------------|----------------------------------------
# Attractor lock-in         | I_t > 0 (persistence flips positive)
# Brittle oscillation       | high σ_t (tension > 0.35)
# Loop degeneration         | high σ_t + entropy collapse
# Rigid low-rank collapse   | spectral compression
# Curvature collapse        | κ_t → 0
# =====================================================================

def classify_failures(hierarchy, entropy_traces=None, spectral_data=None):
    """
    Classify failure modes from MASSIF hierarchy.
    
    Returns:
        failure_signatures: Dict with booleans per failure type
        active_failures: List of currently active failure modes
    """
    mean_I = np.array(hierarchy['mean_I'])
    sigma_t = np.array(hierarchy['sigma_t'])
    kappa_t = np.array(hierarchy['kappa_t'])
    
    failures = {}
    active = []
    
    # 1. Attractor lock-in: I_t > 0 (persistence flips positive)
    if len(mean_I) > 0 and mean_I[-1] > 0:
        failures['attractor_lock_in'] = True
        active.append('attractor_lock_in')
    else:
        failures['attractor_lock_in'] = False
    
    # 2. Brittle oscillation: high σ_t (>0.35)
    max_sigma = np.nanmax(sigma_t) if len(sigma_t) > 0 else 0
    failures['brittle_oscillation'] = max_sigma > 0.35
    if failures['brittle_oscillation']:
        active.append('brittle_oscillation')
    
    # 3. Loop degeneration: high σ_t + entropy collapse
    failures['loop_degeneration'] = False
    if entropy_traces and max_sigma > 0.25:
        # Check entropy collapse
        all_entropy = np.concatenate(entropy_traces)
        if len(all_entropy) > 10:
            init_entropy = np.mean(all_entropy[:5])
            final_entropy = np.mean(all_entropy[-5:])
            if final_entropy < 0.2 * init_entropy:
                failures['loop_degeneration'] = True
                active.append('loop_degeneration')
    
    # 4. Curvature collapse: κ_t → 0 (approaching straight line)
    if len(kappa_t) > 5:
        final_kappa = np.nanmean(kappa_t[-3:]) if not np.all(np.isnan(kappa_t[-3:])) else 1.0
        failures['curvature_collapse'] = final_kappa < 0.2  # < ~11 degrees
        if failures['curvature_collapse']:
            active.append('curvature_collapse')
    else:
        failures['curvature_collapse'] = False
    
    # 5. Stress accumulation: σ_t rising over time
    if len(sigma_t) > 10:
        early_sigma = np.nanmean(sigma_t[:5])
        late_sigma = np.nanmean(sigma_t[-5:])
        failures['stress_accumulation'] = late_sigma > early_sigma * 1.5
        if failures['stress_accumulation']:
            active.append('stress_accumulation')
    else:
        failures['stress_accumulation'] = False
    
    # Overall instability score (0-1)
    instability_score = len(active) / 5.0
    
    return {
        'failures': failures,
        'active': active,
        'instability_score': instability_score,
        'max_tension': max_sigma
    }

print("✅ Cell 3 complete: Failure mode classification defined")
# =====================================================================
# CELL 0: GENITOR (Unified) — For Colab OR SageMaker Studio Lab
# =====================================================================

import os
import sys
import json
import pickle
import gc
import warnings
from datetime import datetime
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

warnings.filterwarnings('ignore')

# ==================== DETECT ENVIRONMENT ====================
ENVIRONMENT = "colab" if 'google.colab' in sys.modules else "sagemaker"
print(f"🌍 Environment: {ENVIRONMENT}")

# ==================== INSTALL (if needed) ====================
if ENVIRONMENT == "colab":
    !pip install transformers torch numpy pandas matplotlib scipy -q
else:
    # SageMaker usually has these pre-installed
    pass

# ==================== AUTHENTICATION ====================
HF_TOKEN = None
if ENVIRONMENT == "colab":
    try:
        from google.colab import userdata
        HF_TOKEN = userdata.get('colab-read')
        print(f"🔑 HF Token: {'✓ Loaded' if HF_TOKEN else '✗ Missing'}")
    except:
        pass
else:
    # SageMaker: try environment variable
    HF_TOKEN = os.environ.get('HF_TOKEN', None)
    print(f"🔑 HF Token: {'✓ Loaded from env' if HF_TOKEN else '✗ Not set'}")

# ==================== CHECKPOINT DIRECTORY ====================
if ENVIRONMENT == "colab":
    from google.colab import drive
    drive.mount('/content/drive', force_remount=False)
    CHECKPOINT_DIR = Path('/content/drive/MyDrive/massif_checkpoints')
else:
    # SageMaker: local checkpoint directory
    CHECKPOINT_DIR = Path('./massif_checkpoints')

CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
print(f"💾 Checkpoint directory: {CHECKPOINT_DIR}")

# ==================== HARDWARE DETECTION ====================
import torch

HAS_GPU = torch.cuda.is_available()
GPU_NAME = torch.cuda.get_device_name(0) if HAS_GPU else "None"
GPU_MEMORY_GB = torch.cuda.get_device_properties(0).total_memory / 1e9 if HAS_GPU else 0

print(f"\n🖥️ Hardware:")
print(f"   GPU: {HAS_GPU}")
if HAS_GPU:
    print(f"   GPU Name: {GPU_NAME}")
    print(f"   GPU Memory: {GPU_MEMORY_GB:.1f} GB")
else:
    print(f"   Running on CPU (memory limit: ~12.7 GB)")

# ==================== EXECUTION MODE ====================
EXECUTION_MODE = "FULL" if HAS_GPU else "CPU_ONLY"
print(f"\n⚙️ Mode: {EXECUTION_MODE}")
if EXECUTION_MODE == "CPU_ONLY":
    print("   ⚠️ GPU-intensive cells will be skipped or use reduced parameters.")

# ==================== ORCHESTRATOR ====================
class MassifOrchestrator:
    def __init__(self, checkpoint_dir):
        self.checkpoint_dir = Path(checkpoint_dir)
        self.results = {}
        self.checkpoint_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    def save(self, name, data):
        self.results[name] = data
        path = self.checkpoint_dir / f"{name}_{self.checkpoint_id}.pkl"
        with open(path, 'wb') as f:
            pickle.dump(data, f)
        print(f"   💾 Saved: {name}")
    
    def load(self, name):
        existing = list(self.checkpoint_dir.glob(f"{name}_*.pkl"))
        if existing:
            latest = max(existing, key=lambda p: p.stat().st_mtime)
            with open(latest, 'rb') as f:
                return pickle.load(f)
        return None

orchestrator = MassifOrchestrator(CHECKPOINT_DIR)

print("\n✅ GENITOR COMPLETE")
# =====================================================================
# CELL 5: LOAD MODEL WRAPPER
# =====================================================================

from transformers import AutoTokenizer, AutoModelForCausalLM

def load_model_with_interface(model_id, model_name):
    """Load model and wrap with UniversalModelInterface."""
    
    print(f"\n📥 Loading {model_name}...")
    
    tokenizer = AutoTokenizer.from_pretrained(
        model_id, trust_remote_code=True,
        token=HF_TOKEN if HF_TOKEN else None
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    dtype = torch.float16 if HAS_GPU else torch.float32
    
    model = AutoModelForCausalLM.from_pretrained(
        model_id, trust_remote_code=True,
        torch_dtype=dtype,
        device_map="auto" if HAS_GPU else None,
        token=HF_TOKEN if HF_TOKEN else None
    )
    
    if not HAS_GPU:
        model = model.cpu()
    
    model.eval()
    interface = UniversalModelInterface(model, tokenizer)
    
    print(f"   ✓ Loaded on {'GPU' if HAS_GPU else 'CPU'}")
    return model, tokenizer, interface

print("✅ Cell 5 complete: Model loader defined")
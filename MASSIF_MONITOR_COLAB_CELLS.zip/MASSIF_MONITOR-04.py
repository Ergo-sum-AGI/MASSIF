# =====================================================================
# CELL 4: UNIVERSAL MODEL INTERFACE (Fixes NoneType)
# =====================================================================
# TASK: Canonicalize hidden_states and attentions for ANY model
# =====================================================================

class UniversalModelInterface:
    """Unified wrapper for GPT-2, Qwen, RWKV, Mamba, etc."""
    
    def __init__(self, model, tokenizer):
        self.model = model
        self.tokenizer = tokenizer
        self.device = next(model.parameters()).device
        self.model_type = self._detect_model_type()
        
    def _detect_model_type(self):
        name = self.model.__class__.__name__.lower()
        if 'qwen' in name:
            return 'qwen'
        elif 'gpt2' in name:
            return 'gpt2'
        elif 'rwkv' in name:
            return 'rwkv'
        elif 'mamba' in name:
            return 'mamba'
        return 'transformer'
    
    def forward(self, input_ids, **kwargs):
        output_hidden = kwargs.pop('output_hidden_states', True)
        output_attentions = kwargs.pop('output_attentions', True)
        
        # RWKV/Mamba have no attention
        if self.model_type in ['rwkv', 'mamba']:
            outputs = self.model(input_ids, output_hidden_states=output_hidden, **kwargs)
            return {
                'hidden_states': getattr(outputs, 'hidden_states', None),
                'attentions': None,
                'logits': outputs.logits,
                'last_hidden': getattr(outputs, 'hidden_states', [None])[-1] if hasattr(outputs, 'hidden_states') else None,
                'model_type': self.model_type
            }
        
        # Standard transformers
        try:
            outputs = self.model(
                input_ids,
                output_hidden_states=output_hidden,
                output_attentions=output_attentions,
                **kwargs
            )
        except TypeError:
            outputs = self.model(input_ids, output_hidden_states=output_hidden, **kwargs)
            output_attentions = False
        
        hidden = getattr(outputs, 'hidden_states', None)
        if hidden and isinstance(hidden, tuple):
            hidden = list(hidden)
        
        return {
            'hidden_states': hidden,
            'attentions': getattr(outputs, 'attentions', None) if output_attentions else None,
            'logits': outputs.logits,
            'last_hidden': hidden[-1] if hidden else None,
            'model_type': self.model_type
        }

print("✅ Cell 4 complete: UniversalModelInterface defined")
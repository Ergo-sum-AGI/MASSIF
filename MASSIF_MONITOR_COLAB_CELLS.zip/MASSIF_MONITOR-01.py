# =====================================================================
# CELL 1: THE MASSIF HIERARCHY — Core Mathematical Implementation
# =====================================================================
# TASK: Implement the full hierarchy:
#   I_t = persistence
#   σ_t = rolling local tension (NOT global!)
#   Φ_t = volatility gradient
#   Ψ_t = predictive volatility velocity
#   κ_t = curvature
# =====================================================================

def compute_massif_hierarchy(persistence_traces, window_k=4, window_m=3):
    """
    Compute the full MASSIF hierarchy from raw persistence traces.
    
    Input:
        persistence_traces: List[List[float]] — I_t for each run
    
    Returns:
        Dict with all levels: I_t, σ_t, Φ_t, Ψ_t, κ_t
    """
    # Convert to numpy array
    n_runs = len(persistence_traces)
    max_len = max(len(trace) for trace in persistence_traces)
    
    padded = np.full((n_runs, max_len), np.nan)
    for i, trace in enumerate(persistence_traces):
        padded[i, :len(trace)] = trace
    
    # ===== LEVEL 1: I_t (already have) =====
    I_t = padded  # shape: (n_runs, max_len)
    
    # ===== LEVEL 2: σ_t = rolling local tension =====
    # IMPORTANT: σ_t is a SEQUENCE, not a scalar
    sigma_t = np.full((max_len), np.nan)
    for t in range(window_k, max_len):
        # Take window of I_t values across runs at timesteps t-window_k to t
        window_values = I_t[:, t-window_k:t].flatten()
        window_values = window_values[~np.isnan(window_values)]
        if len(window_values) > 1:
            sigma_t[t] = np.std(window_values)
    
    # ===== LEVEL 3: Φ_t = volatility gradient =====
    phi_t = np.diff(sigma_t)  # length = max_len - 1
    
    # ===== LEVEL 4: Ψ_t = smoothed volatility velocity =====
    psi_t = np.full_like(phi_t, np.nan)
    for t in range(window_m, len(phi_t)):
        psi_t[t] = np.mean(phi_t[t-window_m:t])
    
    # Pad to match I_t length
    psi_t_padded = np.full(max_len, np.nan)
    psi_t_padded[1:len(psi_t)+1] = psi_t
    
    # ===== LEVEL 5: κ_t = curvature =====
    mean_I = np.nanmean(I_t, axis=0)
    kappa_t = np.arccos(np.clip(mean_I, -0.999, 0.999))  # arccos(I_t)
    
    return {
        'I_t': I_t,                           # (runs, steps)
        'mean_I': mean_I.tolist(),            # (steps,)
        'sigma_t': sigma_t.tolist(),          # (steps,) — TEMPORAL SEQUENCE
        'phi_t': phi_t.tolist(),              # (steps-1,)
        'psi_t': psi_t_padded.tolist(),       # (steps,)
        'kappa_t': kappa_t.tolist(),          # (steps,)
        'n_runs': n_runs,
        'max_steps': max_len,
        'window_k': window_k,
        'window_m': window_m
    }


def compute_rolling_local_tension_visual(persistence_traces, window_k=4):
    """
    EXPLANATION: Shows WHY σ_t is a sequence, not a scalar.
    
    Demonstrates:
        At t=5: σ_5 = std(I_1, I_2, I_3, I_4, I_5) across runs
        At t=6: σ_6 = std(I_2, I_3, I_4, I_5, I_6) across runs
        ...
    """
    I_array = np.array([trace[:20] for trace in persistence_traces if len(trace) >= 20])
    
    print("\n" + "="*60)
    print("DEMONSTRATION: Rolling Local Tension σ_t")
    print("="*60)
    print(f"Number of runs: {I_array.shape[0]}")
    print(f"Steps available: {I_array.shape[1]}")
    print(f"Window size k = {window_k}")
    print("\nAt each timestep t, we compute σ_t = std(I_{t-k} to I_t) ACROSS ALL RUNS")
    print("This gives a TEMPORAL SEQUENCE of tension values, not a single scalar.\n")
    
    for t in range(window_k, min(15, I_array.shape[1])):
        window = I_array[:, t-window_k:t]
        sigma = np.std(window[~np.isnan(window)])
        print(f"  t={t:2d}: σ_t = {sigma:.4f}  (window: steps {t-window_k} to {t})")
    
    return sigma

print("✅ Cell 1 complete: MASSIF hierarchy implemented")
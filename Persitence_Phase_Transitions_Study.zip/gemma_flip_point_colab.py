# ============================================================
# CELL 1 — Auth (run first, always)
# ============================================================
from google.colab import userdata
from huggingface_hub import login
import os

HF_TOKEN = userdata.get('colab-read')
if not HF_TOKEN:
    raise RuntimeError("Add 'colab-read' token in Runtime > Secrets")

login(token=HF_TOKEN, add_to_git_credential=False)
os.environ["HF_TOKEN"] = HF_TOKEN
os.environ["HUGGING_FACE_HUB_TOKEN"] = HF_TOKEN
print("Authenticated:", HF_TOKEN[:8], "...")

# ============================================================
# CELL 2 — Imports and GPU check
# ============================================================
import torch, numpy as np, matplotlib.pyplot as plt, gc, warnings
warnings.filterwarnings('ignore')
from transformers import AutoTokenizer, AutoModelForCausalLM

device = "cuda" if torch.cuda.is_available() else "cpu"
dtype  = torch.float16 if device == "cuda" else torch.float32
eps    = 1e-6
print(f"Device: {device}")
if device == "cuda":
    total = torch.cuda.get_device_properties(0).total_memory / 1e9
    print(f"GPU: {torch.cuda.get_device_name(0)}  ({total:.1f} GB)")

# ============================================================
# CELL 3 — Load Gemma-2-2B
# ============================================================
print("Loading Gemma-2-2B tokenizer...")
g_tok = AutoTokenizer.from_pretrained("google/gemma-2-2b", token=HF_TOKEN)
if g_tok.pad_token is None:
    g_tok.pad_token = g_tok.eos_token

print("Loading Gemma-2-2B model (~1-2 min on T4)...")
g_mod = AutoModelForCausalLM.from_pretrained(
    "google/gemma-2-2b",
    torch_dtype=dtype,
    device_map="auto",
    max_memory={0: "14GiB", "cpu": "4GiB"},
    low_cpu_mem_usage=True,
    token=HF_TOKEN,
).eval()
print("Gemma-2-2B ready.")
if device == "cuda":
    print(f"VRAM used: {torch.cuda.memory_allocated()/1e9:.1f} GB")

# ============================================================
# CELL 4 — Load GPT-2 (no auth needed)
# ============================================================
print("Loading GPT-2 Small...")
p_tok = AutoTokenizer.from_pretrained("gpt2")
p_tok.pad_token = p_tok.eos_token
p_mod = AutoModelForCausalLM.from_pretrained(
    "gpt2", torch_dtype=dtype).to(device).eval()
print("GPT-2 ready.")

# ============================================================
# CELL 5 — Shared persistence function
# ============================================================
def compute_persistence(model, tokenizer, prompt,
                        max_tokens=15, temperature=0.7):
    inputs    = tokenizer(prompt, return_tensors="pt").to(device)
    input_ids = inputs.input_ids
    h_prev = v_prev = None
    vals = []

    for _ in range(max_tokens):
        with torch.no_grad():
            out   = model(input_ids, output_hidden_states=True)
            logit = out.logits[0, -1, :]
            h_new = out.hidden_states[-1][0, -1]

        pr  = torch.softmax(logit / max(temperature, 1e-4), dim=-1)
        tok = torch.multinomial(pr, 1)
        input_ids = torch.cat([input_ids, tok.unsqueeze(0)], dim=1)
        hu = h_new / (torch.norm(h_new) + eps)

        if h_prev is not None:
            v_t = hu - h_prev
            if v_prev is not None:
                n1 = torch.norm(v_t) + eps
                n2 = torch.norm(v_prev) + eps
                vals.append(float(torch.sum(v_t * v_prev) / (n1 * n2)))
            v_prev = v_t.clone()
        h_prev = hu.clone()

        if tok.item() == tokenizer.eos_token_id:
            break

    gc.collect()
    if device == "cuda":
        torch.cuda.empty_cache()
    return float(np.mean(vals)) if vals else 0.0

# Sanity check
print("\nSanity check...")
sg = compute_persistence(g_mod, g_tok, "I think therefore I am.", 8, 0.7)
sp = compute_persistence(p_mod, p_tok, "I think therefore I am.", 8, 0.7)
print(f"  Gemma  I_t = {sg:+.4f}")
print(f"  GPT-2  I_t = {sp:+.4f}")
print("  Both negative = anti-persistent (expected)")

# ============================================================
# CELL 6 — Flip point sweep and comparison table
# ============================================================
n_values = [2, 4, 6, 8, 10, 12]
temps    = [0.5, 0.7, 0.9]

print("\n" + "="*70)
print("FLIP POINT SWEEP  —  prompt = 'I ' repeated n times")
print("="*70)

gemma_res = {}
gpt2_res  = {}

for n in n_values:
    prompt = ("I ") * n
    gemma_res[n] = {T: compute_persistence(g_mod, g_tok, prompt, 12, T)
                    for T in temps}
    gpt2_res[n]  = {T: compute_persistence(p_mod, p_tok, prompt, 12, T)
                    for T in temps}

# Table header
print(f"\n{'n':>4}  " + "  ".join(f"G{T:.1f}   P{T:.1f}" for T in temps))
print("-" * 58)
for n in n_values:
    row = f"  {n:2d}  "
    flipped = False
    for T in temps:
        gv = gemma_res[n][T]
        pv = gpt2_res[n][T]
        row += f"  {gv:+.3f}  {pv:+.3f}"
        if gv > 0 or pv > 0:
            flipped = True
    row += "  <- FLIP" if flipped else ""
    print(row)

print("\nG = Gemma-2-2B   P = GPT-2 Small")
print("Negative = anti-persistent (expected universal behaviour)")
print("Positive = persistence flip (regime change)")

# ============================================================
# CELL 7 — Plot
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(14, 5), sharey=True)
fig.suptitle(
    "Flip Point Comparison: Gemma-2-2B vs GPT-2 Small\n"
    "I_t < 0 = anti-persistent  |  I_t > 0 = persistent (flip)\n"
    "DUBITO Inc. / Ergo Sum AGI Safety Systems",
    fontsize=11, fontweight="bold")

colors = {0.5: "steelblue", 0.7: "tomato", 0.9: "seagreen"}

for ax, (res, title) in zip(
    axes,
    [(gemma_res, "Gemma-2-2B  (2B params)"),
     (gpt2_res,  "GPT-2 Small (117M params)")]
):
    for T in temps:
        ax.plot(n_values, [res[n][T] for n in n_values],
                "o-", color=colors[T], lw=2, ms=7, label=f"T={T}")
    ax.axhline(0, color="black", ls="--", lw=1.2, label="Flip (I_t=0)")
    ax.fill_between(
        n_values,
        [min(res[n][T] for T in temps) for n in n_values], 0,
        where=[min(res[n][T] for T in temps) < 0 for n in n_values],
        alpha=0.08, color="steelblue")
    ax.set_xlabel("Repetition length n", fontsize=11)
    ax.set_ylabel("Mean persistence I_t", fontsize=11)
    ax.set_title(title, fontsize=11)
    ax.legend(fontsize=9); ax.grid(alpha=0.3)

plt.tight_layout()
plt.savefig("gemma_vs_gpt2_flip.png", dpi=150, bbox_inches="tight")
plt.show()
print("Plot saved: gemma_vs_gpt2_flip.png")

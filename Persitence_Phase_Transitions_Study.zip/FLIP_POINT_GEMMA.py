# ==============================================================
# PROPER STATISICAL PROTOCOL FOR FLIP POINT DETECTION
# GMEMMA-2-2B vs GPT-2
# Multiple runs per (n, T) + error bars + monotonicity test
# ==============================================================

import torch
import numpy as np
import matplotlib.pyplot as plt
from transformers import AutoTokenizer, AutoModelForCausalLM
import gc
import time
from scipy import stats

# ==============================================================
# CONFIGURATION
# ==============================================================

MODEL_ID = "google/gemma-2-2b"
HF_TOKEN = userdata.get('colab-read')  # Already defined

N_RUNS = 5          # Multiple runs per condition
MAX_TOKENS = 30     # More velocity pairs (was 12 → now 28-29 pairs)
N_VALUES = [2, 4, 6, 8, 10, 12, 15, 20]
TEMPS = [0.5, 0.7, 0.9]

print("=" * 70)
print("GEMMA-2-2B FLIP POINT ANALYSIS WITH ERROR BARS")
print(f"Protocol: {N_RUNS} runs per (n, T), {MAX_TOKENS} tokens per run")
print("=" * 70)

# ==============================================================
# PERSISTENCE COMPUTATION WITH STABLE STATE
# ==============================================================

def compute_persistence_stable(model, tokenizer, prompt, max_tokens=MAX_TOKENS,
                                temperature=0.7, seed=None):
    """Compute persistence with stable state tracking"""
    if seed is not None:
        torch.manual_seed(seed)
        np.random.seed(seed)

    inputs = tokenizer(prompt, return_tensors='pt').to(device)
    input_ids = inputs.input_ids

    h_prev = None
    v_prev = None
    persistence_vals = []

    with torch.no_grad():
        for step in range(max_tokens):
            outputs = model(input_ids, output_hidden_states=True)
            logits = outputs.logits[0, -1, :]
            h_new = outputs.hidden_states[-1][0, -1]

            # Sample with temperature
            if temperature > 0:
                probs = torch.softmax(logits / temperature, dim=-1)
                next_token = torch.multinomial(probs, 1)
            else:
                next_token = torch.argmax(logits, keepdim=True)

            input_ids = torch.cat([input_ids, next_token.unsqueeze(0)], dim=1)

            # Normalize hidden state
            hu = h_new / (torch.norm(h_new) + 1e-6)

            if h_prev is not None:
                v_t = hu - h_prev

                if v_prev is not None:
                    n1 = torch.norm(v_t) + 1e-6
                    n2 = torch.norm(v_prev) + 1e-6
                    persistence = float(torch.sum(v_t * v_prev) / (n1 * n2))
                    persistence_vals.append(persistence)
                v_prev = v_t.clone()

            h_prev = hu.clone()

            if next_token.item() == tokenizer.eos_token_id:
                break

    return np.mean(persistence_vals) if persistence_vals else 0.0


def compute_persistence_with_error(model, tokenizer, prompt, max_tokens=MAX_TOKENS,
                                    temperature=0.7, n_runs=N_RUNS):
    """Compute mean and std across multiple runs"""
    values = []
    for run in range(n_runs):
        seed = 42 + run
        val = compute_persistence_stable(model, tokenizer, prompt,
                                          max_tokens, temperature, seed)
        values.append(val)
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    mean_val = np.mean(values)
    std_val = np.std(values)
    ci_low, ci_high = np.percentile(values, [2.5, 97.5])

    return mean_val, std_val, ci_low, ci_high, values


# ==============================================================
# LOAD MODELS
# ==============================================================

device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"\nDevice: {device}")

# Load Gemma
print("\nLoading Gemma-2-2B...")
tokenizer_g = AutoTokenizer.from_pretrained(MODEL_ID, token=HF_TOKEN)
model_g = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    torch_dtype=torch.float16,
    device_map="auto",
    token=HF_TOKEN
).eval()
print("Gemma loaded")

# Load GPT-2 for comparison
print("\nLoading GPT-2 Small...")
tokenizer_p = AutoTokenizer.from_pretrained("gpt2")
model_p = AutoModelForCausalLM.from_pretrained(
    "gpt2",
    torch_dtype=torch.float16 if device == "cuda" else torch.float32
).to(device).eval()
print("GPT-2 loaded")

# ==============================================================
# RUN SWEEP WITH ERROR BARS
# ==============================================================

print("\n" + "=" * 70)
print("RUNNING SWEEP WITH ERROR BARS")
print("=" * 70)

results = []

for n in N_VALUES:
    prompt = ("I " * n).strip()
    print(f"\n--- n={n} ---")

    for T in TEMPS:
        # Gemma
        mean_g, std_g, lo_g, hi_g, vals_g = compute_persistence_with_error(
            model_g, tokenizer_g, prompt, max_tokens=MAX_TOKENS, temperature=T
        )

        # GPT-2
        mean_p, std_p, lo_p, hi_p, vals_p = compute_persistence_with_error(
            model_p, tokenizer_p, prompt, max_tokens=MAX_TOKENS, temperature=T
        )

        results.append({
            'n': n, 'T': T,
            'gemma_mean': mean_g, 'gemma_std': std_g, 'gemma_ci_lo': lo_g, 'gemma_ci_hi': hi_g,
            'gpt2_mean': mean_p, 'gpt2_std': std_p, 'gpt2_ci_lo': lo_p, 'gpt2_ci_hi': hi_p,
            'gemma_flip': mean_g > 0, 'gpt2_flip': mean_p > 0
        })

        # Print with confidence intervals
        print(f"  T={T}: Gemma = {mean_g:+.4f} ± {std_g:.4f} [95% CI: {lo_g:+.4f}, {hi_g:+.4f}]")
        print(f"        GPT-2  = {mean_p:+.4f} ± {std_p:.4f} [95% CI: {lo_p:+.4f}, {hi_p:+.4f}]")

# ==============================================================
# ANALYSIS: MONOTONIC TREND TEST
# ==============================================================

print("\n" + "=" * 70)
print("MONOTONIC TREND ANALYSIS")
print("=" * 70)

for T in TEMPS:
    print(f"\nTemperature T={T}:")

    # Extract Gemma means for this temperature
    gemma_means = [r['gemma_mean'] for r in results if r['T'] == T]
    gemma_stds = [r['gemma_std'] for r in results if r['T'] == T]

    # Find first n where mean > 0 (potential flip point)
    first_positive = None
    for i, n in enumerate(N_VALUES):
        if gemma_means[i] > 0:
            first_positive = n
            break

    # Check monotonicity: once positive, should stay positive
    if first_positive:
        after_first = gemma_means[N_VALUES.index(first_positive):]
        is_monotonic = all(m > 0 for m in after_first) if after_first else False
        print(f"  First positive at n={first_positive}")
        print(f"  Monotonic (positive thereafter): {is_monotonic}")
        if not is_monotonic:
            print(f"  ⚠️ NOT MONOTONIC — flips back to negative")
    else:
        print(f"  No positive persistence detected (all means ≤ 0)")

# ==============================================================
# PLOT WITH ERROR BARS
# ==============================================================

fig, axes = plt.subplots(1, 2, figsize=(14, 6))

colors = ['blue', 'orange', 'green']
temps_display = {0.5: 'T=0.5', 0.7: 'T=0.7', 0.9: 'T=0.9'}

# Gemma plot
ax1 = axes[0]
for i, T in enumerate(TEMPS):
    n_vals = [r['n'] for r in results if r['T'] == T]
    means = [r['gemma_mean'] for r in results if r['T'] == T]
    errs = [r['gemma_std'] for r in results if r['T'] == T]

    ax1.errorbar(n_vals, means, yerr=errs, fmt='o-', color=colors[i],
                 capsize=5, label=temps_display[T], linewidth=2, markersize=8)
ax1.axhline(y=0, color='red', linestyle='--', linewidth=1.5, label='Iₜ = 0')
ax1.set_xlabel('Number of repetitions (n)', fontsize=12)
ax1.set_ylabel('Persistence (Iₜ)', fontsize=12)
ax1.set_title('Gemma-2-2B: Persistence vs Repetition', fontsize=12)
ax1.legend()
ax1.grid(True, alpha=0.3)

# GPT-2 plot
ax2 = axes[1]
for i, T in enumerate(TEMPS):
    n_vals = [r['n'] for r in results if r['T'] == T]
    means = [r['gpt2_mean'] for r in results if r['T'] == T]
    errs = [r['gpt2_std'] for r in results if r['T'] == T]

    ax2.errorbar(n_vals, means, yerr=errs, fmt='s-', color=colors[i],
                 capsize=5, label=temps_display[T], linewidth=2, markersize=8)
ax2.axhline(y=0, color='red', linestyle='--', linewidth=1.5, label='Iₜ = 0')
ax2.set_xlabel('Number of repetitions (n)', fontsize=12)
ax2.set_ylabel('Persistence (Iₜ)', fontsize=12)
ax2.set_title('GPT-2 Small: Persistence vs Repetition', fontsize=12)
ax2.legend()
ax2.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('gemma_flip_with_errorbars.png', dpi=150)
plt.show()

print("\n📁 Plot saved: gemma_flip_with_errorbars.png")

# ==============================================================
# FINAL VERDICT
# ==============================================================

print("\n" + "=" * 70)
print("FINAL VERDICT")
print("=" * 70)

# Count how many (n, T) combinations show mean > 0
positive_count = sum(1 for r in results if r['gemma_mean'] > 0)
total = len(results)

print(f"\nGemma-2-2B: {positive_count}/{total} conditions show mean Iₜ > 0")

# Check for consistent monotonic trend
monotonic_found = False
for T in TEMPS:
    means = [r['gemma_mean'] for r in results if r['T'] == T]
    # Check if means become positive and stay positive
    for i in range(len(means)):
        if means[i] > 0:
            if all(m > 0 for m in means[i:]):
                print(f"\n✅ MONOTONIC TREND detected at T={T}: positive from n={N_VALUES[i]} onward")
                monotonic_found = True
                break
    if not monotonic_found:
        print(f"\n⚠️ No monotonic trend at T={T}: positive values appear and disappear")

if not monotonic_found:
    print("\n" + "=" * 70)
    print("CONCLUSION")
    print("=" * 70)
    print("""
    The current data does NOT support a deterministic flip point.
    Persistence values oscillate between positive and negative with no monotonic trend.
    Error bars overlap substantially.

    The robust finding remains:
    - Anti-persistence (Iₜ < 0) is universal for most inputs
    - Occasional positive values occur but are not systematic

    To establish a true phase transition, we would need:
    1. Monotonic trend (negative → positive at a specific n)
    2. Non-overlapping confidence intervals
    3. Replication across temperatures
    4. Null control showing effect is specific to repetition
    """)
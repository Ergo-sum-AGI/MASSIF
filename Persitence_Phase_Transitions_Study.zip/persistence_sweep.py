# ==============================================================
# CORRECTED SWEEP: 6 MODELS (Memory Optimized)
# Sequential loading + aggressive cleanup
# ==============================================================

import torch
import numpy as np
import matplotlib.pyplot as plt
from transformers import AutoTokenizer, AutoModelForCausalLM
import gc
import time
import pandas as pd

# ==============================================================
# CONFIGURATION
# ==============================================================

N_RUNS = 5              # Multiple runs per condition
MAX_TOKENS = 25         # Reduced from 30 to save memory
N_VALUES = [2, 4, 6, 8, 10, 12, 15, 20]
TEMPS = [0.5, 0.7, 0.9]
TOKEN = "I"

# Models to test (excluding Gemma - already done)
MODELS = [
    ("GPT-2 Small", "gpt2"),
    ("GPT-2 Medium", "gpt2-medium"),
    ("GPT-2 Large", "gpt2-large"),
    ("GPT-2 XL", "gpt2-xl"),
    ("TinyLlama 1.1B", "TinyLlama/TinyLlama-1.1B-Chat-v1.0"),
    ("Qwen2 0.5B", "Qwen/Qwen2-0.5B"),
    ("Bloom-560M", "bigscience/bloom-560m"),
]

device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Device: {device}")
print(f"Available GPU memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB" if device == "cuda" else "CPU mode")

# ==============================================================
# PERSISTENCE COMPUTATION (Memory Efficient)
# ==============================================================

def compute_persistence_single(model, tokenizer, prompt, max_tokens=MAX_TOKENS, temperature=0.7, seed=None):
    """Single run persistence computation"""
    if seed is not None:
        torch.manual_seed(seed)
        np.random.seed(seed)

    inputs = tokenizer(prompt, return_tensors='pt').to(device)
    input_ids = inputs.input_ids

    h_prev = None
    v_prev = None
    persistence_vals = []

    with torch.no_grad():
        for step in range(max_tokens):
            outputs = model(input_ids, output_hidden_states=True)
            logits = outputs.logits[0, -1, :]
            h_new = outputs.hidden_states[-1][0, -1]

            if temperature > 0:
                probs = torch.softmax(logits / temperature, dim=-1)
                next_token = torch.multinomial(probs, 1)
            else:
                next_token = torch.argmax(logits, keepdim=True)

            input_ids = torch.cat([input_ids, next_token.unsqueeze(0)], dim=1)

            hu = h_new / (torch.norm(h_new) + 1e-6)

            if h_prev is not None:
                v_t = hu - h_prev

                if v_prev is not None:
                    n1 = torch.norm(v_t) + 1e-6
                    n2 = torch.norm(v_prev) + 1e-6
                    persistence = float(torch.sum(v_t * v_prev) / (n1 * n2))
                    persistence_vals.append(persistence)
                v_prev = v_t.clone()

            h_prev = hu.clone()

            if next_token.item() == tokenizer.eos_token_id:
                break

    return np.mean(persistence_vals) if persistence_vals else 0.0


def compute_model_results(model, tokenizer, model_name):
    """Run complete sweep for a single model"""
    results = []

    for n in N_VALUES:
        prompt = (TOKEN + ' ') * n
        print(f"  n={n:2d}: ", end="")

        for T in TEMPS:
            values = []
            for run in range(N_RUNS):
                seed = hash(f"{model_name}_{n}_{T}_{run}") % 10000
                val = compute_persistence_single(model, tokenizer, prompt,
                                                  max_tokens=MAX_TOKENS,
                                                  temperature=T, seed=seed)
                values.append(val)
                # Small cleanup between runs
                if device == "cuda":
                    torch.cuda.empty_cache()

            mean_val = np.mean(values)
            std_val = np.std(values)
            ci_lo, ci_hi = np.percentile(values, [2.5, 97.5])

            results.append({
                'model': model_name,
                'n': n,
                'T': T,
                'mean': mean_val,
                'std': std_val,
                'ci_lo': ci_lo,
                'ci_hi': ci_hi,
                'flip': mean_val > 0
            })

            status = "FLIP" if mean_val > 0 else "    "
            print(f" T={T}: {mean_val:+.4f}±{std_val:.4f} {status}", end="")

        print()  # newline after each n

    return results


# ==============================================================
# LOAD AND PROCESS MODELS ONE BY ONE
# ==============================================================

print("=" * 70)
print("RUNNING CORRECTED SWEEP (Memory Optimized)")
print(f"n_runs={N_RUNS} | max_tokens={MAX_TOKENS}")
print("=" * 70)

all_results = []

for model_name, model_id in MODELS:
    print(f"\n{'='*60}")
    print(f"Processing: {model_name}")
    print(f"{'='*60}")

    # Clear memory before loading new model
    gc.collect()
    if device == "cuda":
        torch.cuda.empty_cache()
        print(f"  GPU memory before load: {torch.cuda.memory_allocated()/1e9:.2f} GB")

    try:
        # Load model
        print(f"  Loading {model_id}...")
        tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
        model = AutoModelForCausalLM.from_pretrained(
            model_id,
            torch_dtype=torch.float16 if device == "cuda" else torch.float32,
            low_cpu_mem_usage=True,
            trust_remote_code=True
        ).to(device).eval()

        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token

        print(f"  ✅ Loaded")

        # Run sweep
        results = compute_model_results(model, tokenizer, model_name)
        all_results.extend(results)

        # Cleanup
        del model
        del tokenizer
        gc.collect()
        if device == "cuda":
            torch.cuda.empty_cache()
            print(f"  GPU memory after cleanup: {torch.cuda.memory_allocated()/1e9:.2f} GB")

    except Exception as e:
        print(f"  ❌ Failed: {e}")
        continue

# ==============================================================
# SAVE RESULTS
# ==============================================================

df_results = pd.DataFrame(all_results)
df_results.to_csv('all_models_flip_data.csv', index=False)
print(f"\n✅ Results saved to all_models_flip_data.csv")

# ==============================================================
# ANALYSIS
# ==============================================================

print("\n" + "=" * 70)
print("FLIP POINT SUMMARY")
print("=" * 70)

for model_name in df_results['model'].unique():
    print(f"\n{model_name}:")

    for T in TEMPS:
        subset = df_results[(df_results['model'] == model_name) & (df_results['T'] == T)]
        subset = subset.sort_values('n')

        # Find first n where mean > 0 and stays positive
        means = subset['mean'].values
        n_vals = subset['n'].values

        first_positive = None
        for i, m in enumerate(means):
            if m > 0:
                # Check if all subsequent are also positive
                if all(m2 > 0 for m2 in means[i:]):
                    first_positive = n_vals[i]
                    break

        if first_positive:
            print(f"  T={T}: flip at n={first_positive}")
        else:
            print(f"  T={T}: no monotonic flip detected")

# ==============================================================
# PLOT
# ==============================================================

n_models = len(df_results['model'].unique())
fig, axes = plt.subplots(n_models, 1, figsize=(12, 4 * n_models))
if n_models == 1:
    axes = [axes]

colors = ['blue', 'orange', 'green']

for idx, model_name in enumerate(df_results['model'].unique()):
    ax = axes[idx]

    for i, T in enumerate(TEMPS):
        subset = df_results[(df_results['model'] == model_name) & (df_results['T'] == T)]
        subset = subset.sort_values('n')

        ax.errorbar(subset['n'], subset['mean'], yerr=subset['std'],
                   fmt='o-', color=colors[i], capsize=5,
                   label=f'T={T}', linewidth=2, markersize=6)

    ax.axhline(y=0, color='red', linestyle='--', linewidth=1.5)
    ax.set_xlabel('Number of repetitions (n)')
    ax.set_ylabel('Persistence (Iₜ)')
    ax.set_title(f'{model_name}')
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.set_ylim(-1.2, 1.2)

plt.tight_layout()
plt.savefig('remaining_models_flip_analysis.png', dpi=150)
plt.show()

print("\n📁 Plot saved: remaining_models_flip_analysis.png")

# ==============================================================
# FINAL SUMMARY TABLE
# ==============================================================

print("\n" + "=" * 70)
print("FINAL SUMMARY TABLE")
print("=" * 70)

summary_data = []
for model_name in df_results['model'].unique():
    row = {'Model': model_name}

    for T in TEMPS:
        subset = df_results[(df_results['model'] == model_name) & (df_results['T'] == T)]
        subset = subset.sort_values('n')

        means = subset['mean'].values
        n_vals = subset['n'].values

        first_positive = None
        for i, m in enumerate(means):
            if m > 0 and all(m2 > 0 for m2 in means[i:]):
                first_positive = n_vals[i]
                break

        row[f'Flip at T={T}'] = first_positive if first_positive else 'Never'

    summary_data.append(row)

df_summary = pd.DataFrame(summary_data)
print(df_summary.to_string(index=False))

print("\n" + "=" * 70)
print("COMPLETE")
print("=" * 70)